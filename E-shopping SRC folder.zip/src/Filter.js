import React from 'react'

const Filter = () => {
  return (
    <div id='filter'>
        <div className='f1'>All</div>
        <div className='f1'>Mobile</div>
        <div className='f1'>Laptop</div>
        <div className='f1'>Tablet</div>
    </div>
  )
}

export default Filter