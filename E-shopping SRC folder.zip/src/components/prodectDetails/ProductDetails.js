import React from 'react'
import { Link, useParams } from 'react-router-dom';
import './ProductDetails.css'

const ProductDetails = ({items}) => {
    const { id } = useParams();
    const [product] = items.filter(post => (post.id) == id);
    //console.log(post)
  return (
    <div id='product-Details'>
        <img
            src={product.imgSrc}
            className="card-img-top"
            alt="..."
        />
        <div className="product-details">
            <h2 className="card-title">{product.title}</h2>
            <p>Category : <b> {product.category} </b> </p>
            <p className="card-text">{product.description}</p>
                <h3 style={{color:"red"}}>{product.price} ₹ </h3>
              <Link to='/order'>  <button> Place Order </button>   </Link>         
        </div>

    </div>
  )
}

export default ProductDetails