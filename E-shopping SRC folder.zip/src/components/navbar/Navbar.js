import React from 'react'
import './Navbar.css'
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import { Link } from 'react-router-dom';

const Navbar = ({search,setSearch}) => {
  return (
    <div id='Navbar'>
        <ul id='logo'>
            <li><ShoppingCartIcon/></li>
            <li>upGrade E-Shop</li>
        </ul>
        <form className="searchForm" onSubmit={(e) => e.preventDefault()}>
                <input
                    id="search"
                    type="text"
                    placeholder=" Search"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                />
        </form>

        <ul className='log'>
            <li> <Link to='/'>Home</Link> </li>
            <li><button >log in</button></li>
        </ul>
    </div>
  )
}

export default Navbar