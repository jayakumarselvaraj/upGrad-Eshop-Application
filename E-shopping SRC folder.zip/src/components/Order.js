import React from 'react'

const Order = () => {
  return (
    <div>
        <h2>Add Address</h2>
        <form id="form" action="">
            <input type="text" placeholder=' NAME' /> 
            <input type="text" placeholder='CONTACT NUMBER' />
            <input type="text" placeholder='STREET' />
            <input type="text" placeholder='CITY' />
            <input type="text" placeholder='STATE' />
            <input type="text" placeholder='ZIP CODE' />
            <button> Save address </button>
        </form>
        <div id='b2'>
            <button>back</button>
            <button>next</button>
        </div>

    </div>
  )
}

export default Order