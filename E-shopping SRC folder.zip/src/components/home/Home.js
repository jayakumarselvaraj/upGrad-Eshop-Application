import React from 'react'
import { Link } from 'react-router-dom';
import './Home.css'

const Home = ({items}) => {
  return (
    <div id='home'>
      
          {items.map((product) => {
            return (
              
                <div key={product.id} className="product">
                  <div className="card" >
                    <img
                      src={product.imgSrc}
                      className="card-img-top"
                      alt="..."
                      />
                    <div className="card-body">
                      <h3 className="card-title">{product.title}</h3>
                      <p className="card-text">{product.description}</p>
                      <div className='prize-buy'>
                            <h4>{product.price} ₹ </h4>
                            <Link to={`/product/${product.id}`} >
                                <button> BUY </button>
                            </Link>
                      </div>
                     
                    </div>
                  </div>
                </div>
              
            );
          })}
    </div>
  )
}

export default Home