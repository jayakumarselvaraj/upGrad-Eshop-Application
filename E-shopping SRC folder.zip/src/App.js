import './App.css';
import { Route, BrowserRouter as Router, Routes } from 'react-router-dom';
import Home from './components/home/Home';
import Navbar from './components/navbar/Navbar';
import { items } from './components/data/Data';
import { useEffect, useState } from 'react';
import ProductDetails from './components/prodectDetails/ProductDetails';
import Filter from './Filter';
import Order from './components/Order';

function App() {
  let [data, setData]=useState([...items])
  let [search,setSearch] =useState('')
  let [searchResult,setSearchResult]= useState('')
  console.log(data)

  useEffect(()=>{
    let filterResults = data.filter((post)=>
    ((post.title).toLowerCase()).includes(search.toLowerCase()) )
    setSearchResult(filterResults.reverse()) 
  },[data,search])

  //console.log(searchResult)
  //console.log("a1")


  return (
    <div className="App">
      <Router>
        <Navbar search={search} setSearch={setSearch} />
        <Filter/>
          <Routes>
              <Route path='/' element={<Home items={data.filter((item)=>(item.title.toLocaleLowerCase()).includes(search.toLocaleLowerCase() ))}/>} />
              <Route path="/product/:id" element={<ProductDetails items={data}/> } />
              <Route path='/order' element={<Order/>} />
          </Routes>
      </Router>
    </div>
  );
}

export default App;
